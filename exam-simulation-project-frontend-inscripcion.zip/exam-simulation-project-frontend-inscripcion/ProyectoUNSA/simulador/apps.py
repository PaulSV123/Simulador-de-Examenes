from django.apps import AppConfig


class SimuladorConfig(AppConfig):
    name = 'simulador'
